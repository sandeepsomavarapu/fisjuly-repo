package com.fis.spring;

public class Address {
	private int hno;
	private String colony;
	private String city;
	private int pin;

	public int getHno() {
		return hno;
	}

	public void setHno(int hno) {
		this.hno = hno;
	}

	public String getColony() {
		return colony;
	}

	public void setColony(String colony) {
		this.colony = colony;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public Address(int hno, String colony, String city, int pin) {
		super();
		this.hno = hno;
		this.colony = colony;
		this.city = city;
		this.pin = pin;
	}

	public Address() {
		// TODO Auto-generated constructor stub
	}
}
